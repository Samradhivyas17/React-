

import { BrowserRouter, Routes, Route } from 'react-router-dom';

import { Provider } from 'react-redux';
import store from './Components/store';
import Signup from './Components/Signup';
import Login from './Components/Login';
import Home from './Components/Home';


function App() {
  return (
    <>
      <Provider store={store}>

        <BrowserRouter>
          <Routes>
            <Route>
              <Route path='/Signup' element={<Signup />} />
              <Route path='/Login' element={<Login />} />
              <Route path='/Home' element={<Home />} />


            </Route>
          </Routes>

        </BrowserRouter>
      </Provider>

    </>
  );
}

export default App;
