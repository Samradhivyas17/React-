import React from 'react'
import { GoogleLogin } from 'react-google-login';
const GoogleLogin = () => {

    const responseGoogle = (response) => {
        console.log(response);
        // Handle success or failure response from Google login
      };
  return (
  
      <div className="form-group">
  <GoogleLogin
    clientId="YOUR_GOOGLE_CLIENT_ID"
    buttonText="Login with Google"
    onSuccess={responseGoogle}
    onFailure={responseGoogle}
    cookiePolicy={'single_host_origin'}
  />
</div>
   
  )
}

export default GoogleLogin
