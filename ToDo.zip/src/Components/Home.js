import React, { useState, useEffect } from 'react';
import { Tab, Tabs } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import Popup from './Popup';
import MyTask from './My-Task';
import Completed from './Complete';
import './Popup.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faArrowRight, faSun, faMoon, faBars } from '@fortawesome/free-solid-svg-icons';
import Group from './Group (2).png';

const Home = () => {
  const [showPopup, setShowPopup] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);

  useEffect(() => {
    const storedMode = localStorage.getItem('darkMode');
    setIsDarkMode(storedMode === 'true');
  }, []);

  const toggleDarkMode = () => {

    const newMode = !isDarkMode;
    setIsDarkMode(newMode);
    localStorage.setItem('darkMode', newMode);
  };

  const handleCreateTodoClick = () => {
    setShowPopup(true);
  };

  const handleClosePopup = () => {
    setShowPopup(false);
  };

  return (
    <div className='body' style={{}}>
      <nav className={`navbar navbar-expand-lg ${isDarkMode ? 'navbar-dark bg-dark' : 'navbar-light bg-light'}`} style={{ height: '4rem' }}>
        <button className="navbar-toggler bg-white" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
          <span className="navbar-toggler-icon" style={{ color: 'white', paddingRight: '100px' }}></span>
        </button>
        <div className="collapse navbar-collapse d-flex justify-content-left align-items-left" id="navbarTogglerDemo01" style={{ paddingLeft: '6rem' }}>
          <img src={Group} alt='Logo' />
          <h1 className="navbar-brand text-white mx-3" style={{ maxWidth: '300px', marginBottom: '0' }}>Todo-List</h1>
        </div>
        <div className="navbar-collapse collapse">
          <form className="form-inline my-2 my-lg-5 d-flex justify-content-center">
            <input className="form-control" type="search" placeholder="Search" aria-label="Search" style={{ color: 'black' }} />

            <button className="btn btn-outline-success my-2 my-sm-0" type="submit" style={{ color: 'black', width: '15%' }}><FontAwesomeIcon icon={faBars} /></button>
          </form>
        </div>
        <button className="mode-button" onClick={toggleDarkMode}>
          {isDarkMode ? <FontAwesomeIcon icon={faSun} /> : <FontAwesomeIcon icon={faMoon} />}
        </button>
      </nav>
      <div className="container mt-5 mb-8 container-first" style={{ background: '#ACE1AF', height: '150px', width: '60%', }}>
        <div className="row">
          <div className="col-md-8">
            <div className="App">
              <h6 style={{ justifyContent: 'center', paddingTop: '40px', paddingLeft: '70px' }}>Welcome to your</h6>
              <h2 style={{ paddingLeft: '70px' }}>To-Do List Manager</h2>
            </div>
          </div>
          <div className="col-md-4 text-right" style={{ gap: '8px' }}>
            <button type="button" className="btn btn-dark m-4" onClick={handleCreateTodoClick}>
              Create To-do
              <FontAwesomeIcon style={{ marginLeft: '4px' }} icon={faArrowRight} />
            </button>
          </div>
        </div>
      </div>

      <div className="container mt-5" style={{ width: '100%', paddingLeft: '10%' }}>
        <div className="row">
          <div className="col-md-12">
            {showPopup && <Popup onClose={handleClosePopup} />}

            <Tabs defaultActiveKey="myTask" id="uncontrolled-tab-example">
              <Tab eventKey="myTask" title="My Task" className='myTask' >
                <MyTask />
              </Tab>
              <Tab eventKey="completed" title="Completed">
                <Completed />
              </Tab>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;

