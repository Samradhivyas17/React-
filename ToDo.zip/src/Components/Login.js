import React, { useEffect, useState } from 'react';
import { Field, Form, Formik, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { useNavigate } from "react-router-dom";
import signup from './signup.png';
import Group from './Group (2).png';
import './Logiin.css';

function Login() {
  const [isLogin, setIsLogin] = useState(false);
  const navigate = useNavigate();

  const validationSchema = Yup.object().shape({
    Email: Yup.string().email('Invalid email').required('Required'),
    Password: Yup.string().required('Required'),
  });


  const handleSubmit = (values, { setSubmitting }) => {
    console.log(values, isLogin);
    setSubmitting(false);
    if (isLogin.Email === values.Email && isLogin.Password === values.Password) {

      navigate('/Home');
    }
  };

  useEffect(() => {
    const Logindata = localStorage.getItem('Signup');
    const userData = Logindata ? JSON.parse(Logindata) :
      setIsLogin(userData);

  }, []);

  console.log('isLogin', isLogin)
  return (
    <div>
      <div className='main' style={{ display: "flex", justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
        <div className='right' style={{ flex: '1', display: 'flex', justifyContent: "center", alignItems: "center", maxWidth: '50%' }}>
          <img src={signup} alt='image' />
        </div>
        <div className='left'>
          <h2><img src={Group} alt='img' />To-Do List</h2><br />
          <h1 style={{ fontSize: '3.5rem' }}>Login to access <br /> To-Do List</h1>
          <Formik
            initialValues={{ Email: '', Password: '' }}
            validationSchema={validationSchema}
            onSubmit={handleSubmit}
          >
            <Form className='container'>
              <div className="form-group">
                <label htmlFor="Email">
                  Email: <span style={{ color: 'red' }}>*</span>:
                </label>
                <Field
                  type="text"
                  id="Email"
                  name="Email"
                  placeholder="Enter your Email"
                />
                <ErrorMessage name="Email" component="div" />
              </div>

              <div className="form-group">
                <label htmlFor="Password">
                  Password: <span style={{ color: 'red' }}>*</span>:
                </label>
                <Field
                  type="password"
                  id="Password"
                  name="Password"
                  placeholder="Enter your Password"
                />
                <ErrorMessage name="Password" component="div" />
              </div>
              <div className="form-group">
                <label style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div>
                    <Field type="checkbox" name="rememberMe" style={{ backgroundColor: '#Fe7f9c' }} />
                    Remember Me
                  </div>
                  <a href="/forgotpassword" style={{ color: '#Fe7f9c' }}>Forgot password?</a>
                </label>
              </div>
              <button type="submit">Login</button>
            </Form>
          </Formik>
        </div>
      </div>
    </div>
  );
};

export default Login;


