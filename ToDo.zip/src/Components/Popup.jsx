
import React, { useState } from 'react';
import './Popup.css';
import { useDispatch } from 'react-redux';
import { addTodo } from './todoSlice';
import { faXmark } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

const Popup = ({ onClose,onCancel }) => {
  const [todoTitle, setTodoTitle] = useState('');
  const [selectedOption, setSelectedOption] = useState('');
  const [todoColor, setTodoColor] = useState('');
  // const [count, setCount] = useState(0);

  const dispatch = useDispatch();

  const handleOptionClick = (event) => {
    setSelectedOption(event.target.value);
  };

  const handleSubmit = (event) => {
    event.preventDefault();
   
    console.log('Title:', todoTitle);
    console.log('Priority:', selectedOption);
    const currentDate = getCurrentDate();

    dispatch(
      addTodo({
        title: todoTitle,
        priority: selectedOption,
        date: currentDate,
        color: todoColor,
        id: Date.now()
      })
    );

    setTodoTitle('');
    onClose();
  };

  const getCurrentDate = () => {
    const currentDate = new Date();
    const year = currentDate.getFullYear();
    const month = String(currentDate.getMonth() + 1).padStart(2, '0');
    const day = String(currentDate.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const handleColor = (e) => {
  
    setTodoColor(e.target.value);
  };

  return (
    <div className="popup-container">
      <div style={{display: 'flex', justifyContent: 'flex-end'}} >
            <FontAwesomeIcon icon={faXmark} onClick={onClose} />
            </div>
      <form onSubmit={handleSubmit}>
        <label htmlFor="todoTitle">Title:</label>
        <input
          type="text"
          id="todoTitle"
          value={todoTitle}
          onChange={(e) => setTodoTitle(e.target.value)}
        />
        <label htmlFor="myOptions">Select priority</label>
        <select id="myOptions" value={selectedOption} onChange={handleOptionClick}>
          <option value="">Select...</option>
          <option value="Low">Low</option>
          <option value="Medium">Medium</option>
          <option value="High">High</option>
        </select>
        <button type="button" value="#FFB6C1" onClick={handleColor}>
          LightPink
        </button>
        <button type="button" value="#ffffd3" onClick={handleColor}>
          LightYellow
        </button>
        <button type="button" value="lightgreen" onClick={handleColor}>
          LightGreen
        </button>
        <button type="button" value="#d6b4fc" onClick={handleColor}>
          LightPurple
        </button>
        <button type="button" value="skyblue" onClick={handleColor}>
          Skyblue
        </button>

        <button type="submit">Save Todo</button>
      </form>
    </div>
  );
};

export default Popup;




