
import { useSelector } from 'react-redux';
import Task from './Task';
import './Task.css';

const Complete = () => {
  const mytodolist = useSelector((state) => state.todo.todoList);
  console.log(mytodolist);
  const myTask = mytodolist.filter((todo) => todo.completed === true)
  console.log('myTask', myTask)
  return (

    <div className='card-container'>

      {myTask.map((todo) => (
        <Task key={todo.title} todo={todo} />
      ))}
    </div>

  )
}

export default Complete;
