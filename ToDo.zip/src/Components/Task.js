import React, { useState} from 'react';
import { useDispatch } from 'react-redux';
import { completeTodo, removeTodo } from './todoSlice';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEllipsisVertical, faCheckCircle, faCircle } from '@fortawesome/free-solid-svg-icons';
import Edit from './Edit';

const Task = ({ todo }) => {
    const dispatch = useDispatch();
    const [showMenu, setShowMenu] = useState(false);
    const [showEdit, setShowEdit] = useState(false);
    const [editTodo, setEditTodo] = useState({})
    const handleDelete = () => {
        const confirmDelete = window.confirm("Are you sure you want to delete this todo?");
        if (confirmDelete) {
            dispatch(removeTodo(todo.id));
        }
        setShowMenu(false);
    };

    const handleEdit = (todo) => {
        setEditTodo(todo)
        setShowMenu(false);
        setShowEdit(true);
    };

    const handleComplete = () => {
        dispatch(completeTodo(todo.id));
    };

    return (
        <div className={`todo-card ${todo.completed ? 'completed' : ''}`} style={{ background: `${todo.color}`, }}>
            <div className="menu" style={{ display: 'flex', justifyContent: 'space-between' }}>
                <div>
                    {todo.completed ? (
                        <div className="completed-icon">
                            <FontAwesomeIcon icon={faCheckCircle} />
                        </div>
                    ) : (
                        <div className="complete-icon" onClick={handleComplete}>
                            <FontAwesomeIcon icon={faCircle} />
                        </div>
                    )}
                </div>
                <div className="kebab-menu" onClick={() => setShowMenu(!showMenu)}>
                    {showMenu && (
                        <div className="kebab-menu-options" style={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-between', }}>
                            <div className="kebab-option" onClick={() => handleEdit(todo)}>
                                <button className='button'>Edit</button>
                            </div>
                            <div className="kebab-option" onClick={handleDelete} >
                                <button className='button' >Delete</button>
                            </div>
                        </div>
                    )}
                    <FontAwesomeIcon icon={faEllipsisVertical} />

                </div>
            </div>

            {showEdit && (
                <Edit
                    initialTodo={editTodo}
                    onSave={() => {
                     
                        setShowEdit(false);
                    }}
                    onCancel={() => setShowEdit(false)}
                />
            )}
            <p><strong>Title:</strong> {todo.title}</p>
            <p><strong>Priority:</strong> {todo.priority}</p>
            <p><strong>Date:</strong> {todo.date}</p>
        </div>

    );
};

export default Task;
