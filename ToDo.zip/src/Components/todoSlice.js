
import { createSlice } from '@reduxjs/toolkit';

const loadTodoListFromLocalStorage = () => {
  try {
    const storedTodoList = localStorage.getItem('todoList');
    return storedTodoList ? JSON.parse(storedTodoList) : [];
  } catch (error) {
    console.error('Error loading todoList from local storage:', error);
    return [];
  }
};

const saveTodoListToLocalStorage = (todoList) => {
  try {
    localStorage.setItem('todoList', JSON.stringify(todoList));
  } catch (error) {
    console.error('Error saving todoList to local storage:', error);
  }
};

export const todoSlice = createSlice({
  name: 'todos',
  initialState: {
    todoList: loadTodoListFromLocalStorage(),
  },
  reducers: {
    addTodo: (state, action) => {
      const newTodo = { ...action.payload, completed: false };
      state.todoList.push(newTodo);
      saveTodoListToLocalStorage(state.todoList);
    },
    completeTodo: (state, action) => {
      const index = state.todoList.findIndex((todo) => todo.id === action.payload);
      if (index !== -1) {
        state.todoList[index].completed = true;
        saveTodoListToLocalStorage(state.todoList);
      }
    },
    removeTodo: (state, action) => {
      state.todoList = state.todoList.filter((todo) => todo.id !== action.payload);
      saveTodoListToLocalStorage(state.todoList);
    },


    editTodo: (state, action) => {
      const { id, updatedData } = action.payload;
      state.todoList = state.todoList.map(item =>
        item.id === id ? { ...item, ...updatedData } : item
      );
    },
  },
});


export const { addTodo, removeTodo, completeTodo, editTodo } = todoSlice.actions;
export default todoSlice.reducer;
