// import React from 'react';
// import { Field, Form, Formik, ErrorMessage } from 'formik';
// import * as Yup from 'yup';
// import { useNavigate } from "react-router-dom";
// import signup from './signup.png';
// import './Sign.css';

// function Signup() {

//   const navigate = useNavigate();

//   const validationSchema = Yup.object().shape({
//     Name: Yup.string().required('Required'),
//     Email: Yup.string().email('Invalid email')
//       .required('Required'),
//     Password: Yup.string()
//       .required('Required')
//       .min(8, 'Password must be at least 8 characters')
//       .max(20, 'Password must be at most 20 characters'),
//   });

//   const handleSubmit = (values, { setSubmitting }) => {
//     console.log(values, 'string');
//     setSubmitting(false);
//     localStorage.setItem('Signup', JSON.stringify(values));
//     navigate('/Login');
//   };
//   return (

//     <div className='main'>
//       <div className='right'>
//         <img src={signup} alt='image' />
//       </div>
//       <div className='left'>
//         <h2>To-Do List</h2><br /><br />
//         <h1 style={{ fontSize: '3.5rem' }}>Signup to access <br /> To-Do List</h1>
//         <Formik
//           initialValues={{ Name: '', Email: '', Password: '' }}
//           validationSchema={validationSchema}
//           onSubmit={handleSubmit}
//         >
//           <Form className='container'>
//             <div className="form-group">
//               <label htmlFor="FirstName">
//                 Name: <span style={{ color: 'red' }}>*</span>:
//               </label>
//               <Field
//                 type="text"
//                 id="Name"
//                 name="Name"
//                 placeholder="Enter your Name" />
//               <ErrorMessage name="Name" component="div" />
//             </div>
//             <div className="form-group">
//               <label htmlFor="Email">
//                 Email Id: <span style={{ color: 'red' }}>*</span>:
//               </label>
//               <Field
//                 type="text"
//                 id="Email"
//                 name="Email"
//                 placeholder="Enter your Email Id" />
//               <ErrorMessage name="Email Id" component="div" />
//             </div>
//             <div className="form-group">
//               <label htmlFor="Password">
//                 Password: <span style={{ color: 'red' }}>*</span>:
//               </label>
//               <Field
//                 type="password"
//                 id="Password"
//                 name="Password"
//                 placeholder="Enter your Password" />
//               <ErrorMessage name="Password" component="div" />
//             </div>
//             <button type="submit">Sign up</button>
//           </Form>
//         </Formik>
//       </div>
//     </div>


//   );

// }

// export default Signup;


import React from 'react';
import { Field, Form, Formik, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { useNavigate } from "react-router-dom";
import signup from './signup.png';
import Group from './Group (2).png';
import './Sign.css';

function Signup() {

  const navigate = useNavigate();

  const validationSchema = Yup.object().shape({
    Name: Yup.string().required('Required'),
    Email: Yup.string().email('Invalid email')
      .required('Required'),
    Password: Yup.string()
      .required('Required')
      .min(8, 'Password must be at least 8 characters')
      .max(20, 'Password must be at most 20 characters'),
  });

  const handleSubmit = (values, { setSubmitting }) => {
    console.log(values, 'string');
    setSubmitting(false);
    localStorage.setItem('Signup', JSON.stringify(values));
    navigate('/Login');
  };

  return (
    <div className='main'>
      <div className='right'>
        <img src={signup} alt='img' />
      </div>
      <div className='left'>
        <h2> <img src={Group} alt='img' />To-Do List</h2><br />
        <h1 style={{ fontSize: '3.5rem' }}>Signup to access <br /> To-Do List</h1>
        <Formik
          initialValues={{ Name: '', Email: '', Password: '', rememberMe: false }}
          validationSchema={validationSchema}
          onSubmit={handleSubmit}
        >
          <Form className='container'>
            <div className="form-group">
              <label htmlFor="Name">
                Name: <span style={{ color: 'red' }}>*</span>:
              </label>
              <Field
                type="text"
                id="Name"
                name="Name"
                placeholder="Enter your Name" />
              <ErrorMessage name="Name" component="div" />
            </div>
            <div className="form-group">
              <label htmlFor="Email">
                Email Id: <span style={{ color: 'red' }}>*</span>:
              </label>
              <Field
                type="text"
                id="Email"
                name="Email"
                placeholder="Enter your Email Id" />
              <ErrorMessage name="Email" component="div" />
            </div>
            <div className="form-group">
              <label htmlFor="Password">
                Password: <span style={{ color: 'red' }}>*</span>:
              </label>
              <Field
                type="password"
                id="Password"
                name="Password"
                placeholder="Enter your Password" />
              <ErrorMessage name="Password" component="div" />
            </div>
            <div className="form-group">
              <label>
                <Field type="checkbox" name="rememberMe" />
                Accept Terms Conditions & Privacy Policy
              </label>

            </div>
            <button type="submit">Sign up</button>
          </Form>
        </Formik>
      </div>
    </div>
  );
}

export default Signup;
