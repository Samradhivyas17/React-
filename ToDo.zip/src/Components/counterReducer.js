import { createSlice } from "@reduxjs/toolkit";
const todoSlice = createSlice({
  name: "todo",
  initialState: {todolist:[]},
  reducers: {
   addTodo:(state,action)=>{
    state.todolist.push({ tittle: action.payload.tittle, Count: action.payload.count });
   },
   removeTodo:(state,action)=>{
   state.todolist= state.todolist.filter((todo)=>todo.Count!==action.payload);
   }                                
  },
});

export const { addTodo, removeTodo } = todoSlice.actions;
export default todoSlice.reducer;

