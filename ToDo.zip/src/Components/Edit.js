
import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { editTodo } from './todoSlice';
import { faXmark } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import './Edit.css';

const Edit = ({ initialTodo, onSave, onCancel }) => {
    const [editedTitle, setEditedTitle] = useState(initialTodo.title);
    const [editedPriority, setEditedPriority] = useState(initialTodo.priority);
    const [editedColor, setEditedColor] = useState(initialTodo.color);
    const dispatch = useDispatch();

    const handleSave = () => {
        const editedTodo = {
            id: initialTodo.id,
            updatedData: {
                title: editedTitle,
                priority: editedPriority,
                color: editedColor,
            }
        };

        dispatch(editTodo(editedTodo));
        onSave();
    };
    const handleOptionClick = (event) => {
        setEditedPriority(event.target.value);
    };

    const handleColor = (e) => {
        // console.log(e.target.value);
        setEditedColor(e.target.value);
    };


    return (
        <div className="edit-form">
            <div style={{display: 'flex', justifyContent: 'flex-end'}} >
            <FontAwesomeIcon icon={faXmark} onClick={onCancel} />
            </div>
            <label htmlFor="editedTitle"> Title:</label>
            <input
                type="text"
                id="editedTitle"
                value={editedTitle}
                onChange={(e) => setEditedTitle(e.target.value)}
            /><br /> <br />

            <label htmlFor="myOptions">Select priority</label>
            <select id="myOptions" value={editedPriority} onChange={handleOptionClick}>
                <option value="">Select...</option>
                <option value="Low">Low</option>
                <option value="Medium">Medium</option>
                <option value="High">High</option>
            </select><br /> <br />

            <button type="button" value="#FFB6C1" onClick={handleColor}>
                LightPink
            </button>
            <button type="button" value="#ffffd3" onClick={handleColor}>
                LightYellow
            </button>
            <button type="button" value="#ACE1AF" onClick={handleColor}>
                LightGreen
            </button>
            <button type="button" value="#d6b4fc" onClick={handleColor}>
                LightPurple
            </button>
            <button type="button" value="skyblue" onClick={handleColor}>
                Skyblue
            </button>


            <button onClick={handleSave}>Save Changes</button>
            {/* <button onClick={onCancel}>Cancel</button> */}
        </div>
    );
};

export default Edit;

